--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 12.22 (Debian 12.22-1.pgdg120+1)
-- Dumped by pg_dump version 17.10 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE agriculture_rag;
--
-- Name: agriculture_rag; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE agriculture_rag WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE agriculture_rag OWNER TO postgres;

\unrestrict (null)
\connect agriculture_rag
\restrict (null)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: products; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.products (
    id bigint NOT NULL,
    name character varying(200) NOT NULL,
    brand character varying(150),
    product_type character varying(100) NOT NULL,
    description text,
    nitrogen_pct numeric(7,3),
    phosphorus_pct numeric(7,3),
    potassium_pct numeric(7,3),
    magnesium_pct numeric(7,3),
    calcium_pct numeric(7,3),
    sulfur_pct numeric(7,3),
    micronutrients jsonb DEFAULT '{}'::jsonb NOT NULL,
    target_conditions jsonb DEFAULT '[]'::jsonb NOT NULL,
    application_rate numeric(12,4),
    rate_unit character varying(50),
    application_method character varying(100),
    dosage_basis character varying(50),
    water_volume_l_per_acre numeric(12,3),
    product_image_url text,
    product_guide_url text,
    guide_document_id character varying(300),
    label_source text,
    label_verified boolean DEFAULT false NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT chk_application_rate_positive CHECK (((application_rate IS NULL) OR (application_rate > (0)::numeric))),
    CONSTRAINT chk_calcium_pct CHECK (((calcium_pct IS NULL) OR ((calcium_pct >= (0)::numeric) AND (calcium_pct <= (100)::numeric)))),
    CONSTRAINT chk_magnesium_pct CHECK (((magnesium_pct IS NULL) OR ((magnesium_pct >= (0)::numeric) AND (magnesium_pct <= (100)::numeric)))),
    CONSTRAINT chk_micronutrients_object CHECK ((jsonb_typeof(micronutrients) = 'object'::text)),
    CONSTRAINT chk_nitrogen_pct CHECK (((nitrogen_pct IS NULL) OR ((nitrogen_pct >= (0)::numeric) AND (nitrogen_pct <= (100)::numeric)))),
    CONSTRAINT chk_phosphorus_pct CHECK (((phosphorus_pct IS NULL) OR ((phosphorus_pct >= (0)::numeric) AND (phosphorus_pct <= (100)::numeric)))),
    CONSTRAINT chk_potassium_pct CHECK (((potassium_pct IS NULL) OR ((potassium_pct >= (0)::numeric) AND (potassium_pct <= (100)::numeric)))),
    CONSTRAINT chk_sulfur_pct CHECK (((sulfur_pct IS NULL) OR ((sulfur_pct >= (0)::numeric) AND (sulfur_pct <= (100)::numeric)))),
    CONSTRAINT chk_target_conditions_array CHECK ((jsonb_typeof(target_conditions) = 'array'::text)),
    CONSTRAINT chk_water_volume_positive CHECK (((water_volume_l_per_acre IS NULL) OR (water_volume_l_per_acre > (0)::numeric)))
);


ALTER TABLE public.products OWNER TO postgres;

--
-- Name: products_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.products_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.products_id_seq OWNER TO postgres;

--
-- Name: products_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.products_id_seq OWNED BY public.products.id;


--
-- Name: products id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products ALTER COLUMN id SET DEFAULT nextval('public.products_id_seq'::regclass);


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.products (id, name, brand, product_type, description, nitrogen_pct, phosphorus_pct, potassium_pct, magnesium_pct, calcium_pct, sulfur_pct, micronutrients, target_conditions, application_rate, rate_unit, application_method, dosage_basis, water_volume_l_per_acre, product_image_url, product_guide_url, guide_document_id, label_source, label_verified, is_active, created_at, updated_at) FROM stdin;
\.
COPY public.products (id, name, brand, product_type, description, nitrogen_pct, phosphorus_pct, potassium_pct, magnesium_pct, calcium_pct, sulfur_pct, micronutrients, target_conditions, application_rate, rate_unit, application_method, dosage_basis, water_volume_l_per_acre, product_image_url, product_guide_url, guide_document_id, label_source, label_verified, is_active, created_at, updated_at) FROM '$$PATH$$/3000.dat';

--
-- Name: products_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.products_id_seq', 400, true);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: idx_products_active_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_products_active_type ON public.products USING btree (is_active, product_type);


--
-- Name: idx_products_micronutrients; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_products_micronutrients ON public.products USING gin (micronutrients);


--
-- Name: idx_products_target_conditions; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_products_target_conditions ON public.products USING gin (target_conditions);


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

